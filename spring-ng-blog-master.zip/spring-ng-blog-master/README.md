# spring-ng-blog
A simple blog application created using Spring Boot, Spring Security, Spring Data JPA on the backend and Angular 7, Bootstrap on the frontend

You can find the frontend application code at - https://github.com/SaiUpadhyayula/ng-spring-blog-frontend

You can also watch me code this application on Youtube at : https://www.youtube.com/playlist?list=PLSVW22jAG8pCwwM3tjSMfwBKYIS6_fP-F
